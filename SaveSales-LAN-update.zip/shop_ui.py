"""Catalog, independent cashier cart and shared receipts for CustomTkinter."""
import base64
from io import BytesIO
import queue
import threading
import uuid
from datetime import datetime
from tkinter import filedialog, messagebox
import customtkinter as ctk
from PIL import Image, ImageOps
from commerce import Cart, money, price_cents, thumbnail, timestamp

BG='#111827'; PANEL='#1F2937'; BLUE='#2563EB'; GRAY='#374151'; GREEN='#16A34A'; RED='#DC2626'


class ShopUI:
    def __init__(self,app,parent,client,authorize,set_page,get_page):
        self.app,self.parent,self.client,self.authorize=app,parent,client,authorize
        self.set_page,self.get_page=set_page,get_page
        self.items=[];self.sales=[];self.cart=Cart();self.selected=None
        self.customer=ctk.StringVar(master=app,value='')
        self.customer.trace_add('write',lambda *_:setattr(self.cart,'customer_name',self.customer.get()))
        self.notice=ctk.StringVar(master=app,value='')
        self.day=ctk.StringVar(master=app,value=datetime.now().strftime('%Y-%m-%d'))
        self.cards={};self.images={};self.columns=3;self.saving=False
        self.parent.bind('<Configure>',self.resize,add='+')
        self.resize_job=None

    def resize(self,event):
        columns=max(1,min(4,(event.width-30)//225))
        if columns!=self.columns:
            self.columns=columns
            if self.resize_job:self.app.after_cancel(self.resize_job)
            self.resize_job=self.app.after(150,self.reflow)

    def reflow(self):
        self.resize_job=None
        if self.get_page()=='items':self.show_items()

    def clear(self,page):
        self.set_page(page)
        self.cards={}
        for child in self.parent.winfo_children():child.destroy()

    def header(self,title,subtitle):
        header=ctk.CTkFrame(self.parent,fg_color='transparent')
        header.pack(fill='x',padx=22,pady=(18,10))
        labels=ctk.CTkFrame(header,fg_color='transparent');labels.pack(side='left')
        ctk.CTkLabel(labels,text=title,font=('Segoe UI',28,'bold')).pack(anchor='w')
        ctk.CTkLabel(labels,text=subtitle,font=('Segoe UI',12),text_color='#94A3B8').pack(anchor='w')
        ctk.CTkLabel(self.parent,textvariable=self.notice,font=('Segoe UI',12),height=20,text_color='#4ADE80').pack(fill='x',padx=22)
        return header

    def toast(self,text):
        self.notice.set(text)
        self.app.after(5000,lambda:self.notice.set('') if self.notice.get()==text else None)

    def apply_snapshot(self,data):
        if 'items' not in data:return
        changed=self.items!=data['items'];sales_changed=self.sales!=data.get('sales',[])
        self.items=data['items'];self.sales=data.get('sales',[])
        current_ids={item['id'] for item in self.items}
        if self.selected not in current_ids:self.selected=None
        self.images={key:value for key,value in self.images.items() if key in current_ids}
        if self.cart.pending and any(s['id']==self.cart.pending['id'] for s in self.sales):
            self.cart.confirm(self.cart.pending['id']);self.customer.set('');self.saving=False
            self.toast('Sale saved successfully.')
            if self.get_page()=='cart':self.show_cart()
        if changed and self.get_page()=='items':self.show_items()
        if sales_changed and self.get_page()=='tracking':self.show_tracking()

    def photo(self,item):
        if not item.get('image'):return None
        if item['id'] not in self.images:
            image=Image.open(BytesIO(base64.b64decode(item['image']))).convert('RGB')
            image=ImageOps.contain(image,(185,105),Image.Resampling.LANCZOS)
            self.images[item['id']]=ctk.CTkImage(light_image=image,dark_image=image,size=image.size)
        return self.images[item['id']]

    def select(self,item_id):
        self.selected=item_id
        for key,card in self.cards.items():card.configure(border_color=BLUE if key==item_id else GRAY,border_width=2 if key==item_id else 1)

    def show_items(self):
        self.clear('items')
        header=self.header('Items','Manage your products and catalog')
        ctk.CTkButton(header,text='Delete Item',width=100,fg_color=RED,command=self.delete_item).pack(side='right',padx=(8,0))
        ctk.CTkButton(header,text='+ Add Item',width=100,fg_color=BLUE,command=self.add_item).pack(side='right')
        panel=ctk.CTkScrollableFrame(self.parent,fg_color=BG)
        panel.pack(fill='both',expand=True,padx=20,pady=(5,18))
        if not self.items:
            ctk.CTkLabel(panel,text='Your catalog is empty.\nUse + Add Item to create your first product.',font=('Segoe UI',17),text_color='#94A3B8').pack(pady=60)
            return
        for col in range(self.columns):panel.grid_columnconfigure(col,weight=1,uniform='products')
        for index,item in enumerate(self.items):
            card=ctk.CTkFrame(panel,width=205,height=285,corner_radius=12,fg_color=PANEL,border_color=BLUE if item['id']==self.selected else GRAY,border_width=2 if item['id']==self.selected else 1)
            card.grid(row=index//self.columns,column=index%self.columns,sticky='nsew',padx=6,pady=7)
            self.cards[item['id']]=card
            select=lambda event=None,key=item['id']:self.select(key)
            card.bind('<Button-1>',select)
            photo=self.photo(item)
            picture=ctk.CTkLabel(card,text='' if photo else '▧',image=photo,height=110,width=185,fg_color='#172033',corner_radius=8,font=('Segoe UI',38),text_color='#64748B')
            picture.pack(padx=10,pady=(12,5),fill='x');picture.bind('<Button-1>',select)
            for text,font,color,height in [(item['name'],('Segoe UI',16,'bold'),'#F8FAFC',40),(money(item['price_cents']),('Segoe UI',21,'bold'),'#60A5FA',30),((item['description'][:77]+'…') if len(item['description'])>80 else item['description'],('Segoe UI',12),'#94A3B8',38)]:
                label=ctk.CTkLabel(card,text=text,font=font,text_color=color,wraplength=180,height=height,anchor='w',justify='left')
                label.pack(fill='x',padx=12);label.bind('<Button-1>',select)
            ctk.CTkButton(card,text='Add to Cart',height=32,fg_color=BLUE,command=lambda product=item:self.add_to_cart(product)).pack(fill='x',padx=12,pady=(8,12))

    def add_item(self):
        password=self.authorize()
        if password is None:return
        window=ctk.CTkToplevel(self.app);window.title('Add Item');window.geometry('540x560');window.resizable(False,False);window.transient(self.app);window.grab_set()
        ctk.CTkLabel(window,text='New product',font=('Segoe UI',26,'bold')).pack(anchor='w',padx=25,pady=(20,4))
        ctk.CTkLabel(window,text='Add a product to the shared store catalog',text_color='#94A3B8').pack(anchor='w',padx=25)
        form=ctk.CTkFrame(window,fg_color='transparent');form.pack(fill='both',expand=True,padx=25,pady=10)
        ctk.CTkLabel(form,text='Item name',anchor='w').pack(fill='x')
        name=ctk.CTkEntry(form,height=36,placeholder_text='e.g. Coca-Cola');name.pack(fill='x')
        ctk.CTkLabel(form,text='Price (R$)',anchor='w').pack(fill='x',pady=(8,0))
        price=ctk.CTkEntry(form,height=36,placeholder_text='6.00');price.pack(fill='x')
        ctk.CTkLabel(form,text='Description',anchor='w').pack(fill='x',pady=(8,0))
        description=ctk.CTkTextbox(form,height=85);description.pack(fill='x')
        image_row=ctk.CTkFrame(form,fg_color='transparent');image_row.pack(fill='x',pady=10)
        preview=ctk.CTkLabel(image_row,text='No image',height=65,width=100,fg_color=BG,corner_radius=8);preview.pack(side='left')
        status=ctk.CTkLabel(form,text='',text_color='#F87171',wraplength=450,height=35);status.pack(fill='x')
        image_data={'value':None,'busy':False};results=queue.Queue();item_id=str(uuid.uuid4());created=timestamp()
        def select_image():
            path=filedialog.askopenfilename(parent=window,title='Choose product image',filetypes=[('Images','*.jpg *.jpeg *.png *.webp *.bmp'),('All files','*.*')])
            if not path:return
            image_data['busy']=True;save.configure(state='disabled');choose.configure(state='disabled');status.configure(text='Preparing thumbnail…')
            def prepare():
                try:results.put((thumbnail(path),None))
                except Exception as exc:results.put((None,str(exc)))
            threading.Thread(target=prepare,daemon=True).start()
            def poll():
                if not window.winfo_exists():return
                try:value,error=results.get_nowait()
                except queue.Empty:window.after(100,poll);return
                image_data['busy']=False;save.configure(state='normal');choose.configure(state='normal');status.configure(text=error or '')
                if not error:
                    image_data['value']=value
                    image=ImageOps.contain(Image.open(BytesIO(base64.b64decode(value))),(100,65))
                    preview.image=ctk.CTkImage(image,image,size=image.size);preview.configure(image=preview.image,text='')
            poll()
        choose=ctk.CTkButton(image_row,text='Choose image (optional)',command=select_image,width=210,fg_color=GRAY)
        choose.pack(side='left',padx=15)
        def submit():
            try:
                if not name.get().strip():raise ValueError('Item name is required.')
                payload=dict(id=item_id,name=name.get().strip(),price_cents=price_cents(price.get()),description=description.get('1.0','end').strip(),image=image_data['value'],created_at=created)
                if len(payload['name'])>200 or len(payload['description'])>2000:raise ValueError('Use at most 200 characters for name and 2000 for description.')
            except ValueError as exc:status.configure(text=str(exc));return
            save.configure(state='disabled');status.configure(text='Saving to LAN…')
            def done(ok,result):
                if not window.winfo_exists():return
                if ok:window.destroy();self.toast('Item added to the shared catalog.')
                else:save.configure(state='normal');status.configure(text=str(result))
            self.client.submit('POST','/items',payload,password,done)
        buttons=ctk.CTkFrame(window,fg_color='transparent');buttons.pack(fill='x',padx=25,pady=(0,18))
        save=ctk.CTkButton(buttons,text='Save Item',height=36,command=submit);save.pack(side='right')
        ctk.CTkButton(buttons,text='Cancel',fg_color=GRAY,height=36,command=window.destroy).pack(side='left')

    def delete_item(self):
        item=next((i for i in self.items if i['id']==self.selected),None)
        if not item:self.toast('Click a product card to select it first.');return
        password=self.authorize()
        if password is None:return
        if not messagebox.askyesno('Delete catalog item',f"Permanently delete {item['name']} from the catalog?\nPreviously saved sales will remain unchanged.",parent=self.app):return
        def done(ok,result):
            if ok:self.toast('Item deleted from the shared catalog.')
            else:messagebox.showerror('SaveSales',str(result),parent=self.app)
        self.client.submit('DELETE','/items',{'id':item['id']},password,done)

    def add_to_cart(self,item):
        try:self.cart.add(item);self.toast(f"{item['name']} added · {sum(r['quantity'] for r in self.cart.rows.values())} item(s) in cart")
        except ValueError as exc:messagebox.showerror('Cart',str(exc),parent=self.app)

    def change_quantity(self,item_id,change):
        try:self.cart.quantity(item_id,change);self.show_cart()
        except ValueError as exc:messagebox.showerror('Cart',str(exc),parent=self.app)

    def remove(self,item_id):
        try:self.cart.remove(item_id);self.show_cart()
        except ValueError as exc:messagebox.showerror('Cart',str(exc),parent=self.app)

    def show_cart(self):
        self.clear('cart');self.header('Cart','Current customer purchase')
        customer_row=ctk.CTkFrame(self.parent,fg_color='transparent');customer_row.pack(fill='x',padx=22,pady=(5,10))
        ctk.CTkLabel(customer_row,text='Customer name (optional)',font=('Segoe UI',13)).pack(side='left',padx=(0,15))
        ctk.CTkEntry(customer_row,textvariable=self.customer,height=34,state='disabled' if self.cart.pending else 'normal').pack(side='left',fill='x',expand=True)
        footer=ctk.CTkFrame(self.parent,fg_color=BG,corner_radius=10);footer.pack(side='bottom',fill='x',padx=20,pady=(5,18))
        totals=ctk.CTkFrame(footer,fg_color='transparent');totals.pack(side='left',padx=18,pady=12)
        ctk.CTkLabel(totals,text='Subtotal  '+money(self.cart.total),font=('Segoe UI',12),text_color='#94A3B8').pack(anchor='w')
        ctk.CTkLabel(totals,text='Total  '+money(self.cart.total),font=('Segoe UI',23,'bold')).pack(anchor='w')
        ctk.CTkButton(footer,text='Saving…' if self.saving else ('Retry Save Sale' if self.cart.pending else 'Save Sale'),width=165,height=44,fg_color=GREEN,state='disabled' if self.saving or not self.cart.rows else 'normal',command=self.save_sale).pack(side='right',padx=18)
        rows=ctk.CTkScrollableFrame(self.parent,fg_color=BG);rows.pack(fill='both',expand=True,padx=20,pady=5)
        if not self.cart.rows:
            ctk.CTkLabel(rows,text='Your cart is empty.\nAdd products from Items to start a purchase.',font=('Segoe UI',17),text_color='#94A3B8').pack(pady=35)
        for row in self.cart.rows.values():
            line=ctk.CTkFrame(rows,fg_color=PANEL,corner_radius=10);line.pack(fill='x',padx=5,pady=5)
            line.grid_columnconfigure(0,weight=1)
            ctk.CTkLabel(line,text=row['name'],font=('Segoe UI',14,'bold'),wraplength=165,anchor='w',justify='left').grid(row=0,column=0,sticky='w',padx=12,pady=6)
            ctk.CTkLabel(line,text='Unit '+money(row['unit_price_cents']),text_color='#94A3B8',font=('Segoe UI',11)).grid(row=1,column=0,sticky='w',padx=12,pady=(0,8))
            controls=ctk.CTkFrame(line,fg_color='transparent');controls.grid(row=0,column=1,rowspan=2,padx=5)
            state='disabled' if self.cart.pending else 'normal'
            ctk.CTkButton(controls,text='−',width=28,state=state,fg_color=GRAY,command=lambda key=row['item_id']:self.change_quantity(key,-1)).pack(side='left')
            ctk.CTkLabel(controls,text=str(row['quantity']),width=40).pack(side='left')
            ctk.CTkButton(controls,text='+',width=28,state=state,fg_color=GRAY,command=lambda key=row['item_id']:self.change_quantity(key,1)).pack(side='left')
            ctk.CTkLabel(line,text=money(row['unit_price_cents']*row['quantity']),width=115,font=('Segoe UI',14,'bold')).grid(row=0,column=2,rowspan=2,padx=5)
            ctk.CTkButton(line,text='Remove',width=72,fg_color=GRAY,state=state,command=lambda key=row['item_id']:self.remove(key)).grid(row=0,column=3,rowspan=2,padx=(0,10))

    def save_sale(self):
        if self.saving:return
        try:payload=self.cart.prepare()
        except ValueError as exc:messagebox.showerror('Cart',str(exc),parent=self.app);return
        self.saving=True;self.show_cart()
        def done(ok,result):
            self.saving=False
            if ok:
                self.cart.confirm(payload['id']);self.customer.set('');self.toast('Sale saved successfully.')
            else:
                # A definite business rejection permits editing. A timeout/offline
                # result retains the frozen ID and payload for an idempotent retry.
                if getattr(result,'definitive',False):self.cart.pending=None
                messagebox.showerror('Save Sale',str(result),parent=self.app)
            if self.get_page()=='cart':self.show_cart()
        self.client.submit('POST','/sales',payload,callback=done)

    def show_tracking(self):
        self.clear('tracking');self.header('Daily Tracking','Completed sales shared across your store')
        filters=ctk.CTkFrame(self.parent,fg_color='transparent');filters.pack(fill='x',padx=22,pady=8)
        ctk.CTkEntry(filters,textvariable=self.day,width=145).pack(side='left')
        ctk.CTkButton(filters,text='Show date',width=95,command=self.show_tracking).pack(side='left',padx=8)
        try:datetime.strptime(self.day.get(),'%Y-%m-%d')
        except ValueError:self.toast('Use date format YYYY-MM-DD.');return
        sales=[s for s in self.sales if s['date']==self.day.get()]
        ctk.CTkLabel(filters,text=f"{len(sales)} sale(s) · {money(sum(s['total_cents'] for s in sales))}",font=('Segoe UI',16,'bold')).pack(side='right')
        panel=ctk.CTkScrollableFrame(self.parent,fg_color=BG);panel.pack(fill='both',expand=True,padx=20,pady=(5,18))
        if not sales:ctk.CTkLabel(panel,text='No sales saved for this date.',text_color='#94A3B8').pack(pady=35)
        for sale in sales:
            row=ctk.CTkFrame(panel,fg_color=PANEL);row.pack(fill='x',padx=5,pady=5)
            ctk.CTkLabel(row,text=sale['time']+'  ·  '+(sale['customer_name'] or 'Walk-in customer'),anchor='w',wraplength=330,font=('Segoe UI',14)).pack(side='left',padx=12,pady=14)
            ctk.CTkButton(row,text='View',width=65,command=lambda receipt=sale:self.show_receipt(receipt)).pack(side='right',padx=10)
            ctk.CTkLabel(row,text=money(sale['total_cents']),font=('Segoe UI',16,'bold')).pack(side='right',padx=12)

    def show_receipt(self,sale):
        window=ctk.CTkToplevel(self.app);window.title('Saved sale');window.geometry('540x440');window.transient(self.app)
        ctk.CTkLabel(window,text='Sale receipt',font=('Segoe UI',24,'bold')).pack(pady=(20,5))
        ctk.CTkLabel(window,text=f"{sale['date']}  {sale['time']}\n{sale['customer_name'] or 'Walk-in customer'}",wraplength=480).pack()
        rows=ctk.CTkScrollableFrame(window,fg_color=BG);rows.pack(fill='both',expand=True,padx=20,pady=15)
        for row in sale['items']:
            ctk.CTkLabel(rows,text=f"{row['name']}\n{row['quantity']} × {money(row['unit_price_cents'])}  =  {money(row['subtotal_cents'])}",anchor='w',justify='left',wraplength=450).pack(fill='x',padx=10,pady=6)
        ctk.CTkLabel(window,text='Total  '+money(sale['total_cents']),font=('Segoe UI',22,'bold')).pack(pady=5)
        ctk.CTkLabel(window,text='Sale ID: '+sale['id'],font=('Segoe UI',10),text_color='#94A3B8').pack(pady=(0,12))
