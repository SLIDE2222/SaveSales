import customtkinter as ctk
import queue
from tkinter import messagebox
from lan_client import LanClient
from shop_ui import ShopUI
import calendar
import os
import sys

from pathlib import Path
from datetime import datetime


# Some Windows virtual environments do not locate the bundled Tcl/Tk scripts.
if sys.platform == 'win32':
    for variable, folder in (('TCL_LIBRARY', 'tcl8.6'), ('TK_LIBRARY', 'tk8.6')):
        library = Path(sys.base_prefix) / 'tcl' / folder
        if library.is_dir():
            os.environ.setdefault(variable, str(library))

ctk.set_appearance_mode("dark")

app = ctk.CTk()
app.geometry("1000x600")
app.title("SaveSale")


# =========================================================
# COLORS
# =========================================================

background = "#111827"
sidebar_color = "#0F172A"
panel_color = "#1F2937"

blue = "#2563EB"
blue_hover = "#1D4ED8"

green = "#16A34A"
green_hover = "#15803D"

red = "#DC2626"
red_hover = "#B91C1C"

gray = "#374151"
gray_hover = "#4B5563"

yellow = "#CA8A04"

app.configure(fg_color=background)


# =========================================================
# FILES / DATA
# =========================================================

# UI snapshots; the embedded peer service maintains the durable SQLite replica.
employees = []
employee_times = {}
employee_ids = {}
sync_conflicts = []
selected_employee = None
current_page = ('items',)
connected = False
last_ui_date = datetime.now().date()
client = LanClient()


def apply_snapshot(data):
    global employees, employee_times, employee_ids, selected_employee, sync_conflicts
    if 'employees' not in data or 'employee_times' not in data:
        return
    shop.apply_snapshot(data)
    changed = employees != data['employees'] or employee_times != data['employee_times']
    employees, employee_times = data['employees'], data['employee_times']
    employee_ids = data.get('employee_ids', {})
    sync_conflicts = data.get('conflicts', [])
    conflict_button.configure(text=f'Review time conflicts ({len(sync_conflicts)})')
    if sync_conflicts:
        conflict_button.pack(side='bottom', padx=10, pady=5)
    else:
        conflict_button.pack_forget()
    if selected_employee not in employees:
        selected_employee = None
    if changed:
        if current_page[0] == 'employees':
            open_employees()
        elif current_page[0] == 'employee':
            if current_page[1] in employees:
                open_employee_page(*current_page[1:])
            else:
                open_employees()


def process_network():
    global connected, last_ui_date
    today = datetime.now().date()
    if today != last_ui_date:
        last_ui_date = today
        if current_page[0] == 'employee':
            open_employee_page(*current_page[1:])
    try:
        while True:
            kind, result, callback = client.results.get_nowait()
            connected = kind not in ('offline', 'startup_error')
            connection_label.configure(
                text='● Connected / LAN synced' if connected else '● No SaveSales LAN connection',
                text_color=green if connected else red)
            if kind == 'startup_error':
                messagebox.showerror('SaveSales LAN', result, parent=app)
            if kind == 'ok':
                apply_snapshot(result)
            if callback:
                callback(kind == 'ok', result)
    except queue.Empty:
        pass
    app.after(100, process_network)


def mutation_done(ok, result):
    if not ok:
        messagebox.showerror('SaveSales', result, parent=app)


# =========================================================
# SIDEBAR
# =========================================================

sidebar = ctk.CTkFrame(
    app,
    width=220,
    corner_radius=0,
    fg_color=sidebar_color
)

sidebar.pack(
    side="left",
    fill="y"
)

sidebar.pack_propagate(False)


brand_frame = ctk.CTkFrame(
    sidebar,
    fg_color="transparent"
)

brand_frame.pack(
    fill="x",
    padx=22,
    pady=(28, 38)
)

brand_icon = ctk.CTkLabel(
    brand_frame,
    text="S",
    width=42,
    height=42,
    corner_radius=12,
    fg_color=blue,
    font=("Segoe UI", 21, "bold")
)

brand_icon.pack(side="left")

brand_text = ctk.CTkLabel(
    brand_frame,
    text="SaveSales",
    font=("Segoe UI", 25, "bold"),
    text_color="#F8FAFC"
)

brand_text.pack(
    side="left",
    padx=(12, 0)
)


# =========================================================
# MAIN AREA
# =========================================================

main_area = ctk.CTkFrame(
    app,
    corner_radius=15,
    fg_color=panel_color
)

main_area.pack(
    side="right",
    fill="both",
    expand=True,
    padx=20,
    pady=20
)


# =========================================================
# HELPERS
# =========================================================

def clear_page():

    for widget in main_area.winfo_children():

        widget.destroy()


# =========================================================
# ITEMS
# =========================================================

def set_shop_page(page):
    global current_page
    current_page = (page,)


def open_items():
    shop.show_items()


def open_cart():
    shop.show_cart()


def open_tracking():
    shop.show_tracking()


# =========================================================
# ADMIN PASSWORD
# =========================================================

def check_admin_password():

    result = {
        "authorized": None
    }

    password_window = ctk.CTkToplevel(app)

    password_window.title(
        "Admin Access"
    )

    password_window.geometry(
        "400x250"
    )

    password_window.resizable(
        False,
        False
    )

    password_window.transient(app)

    password_window.grab_set()


    title = ctk.CTkLabel(
        password_window,
        text="🔒 Admin Access",
        font=("Arial", 22, "bold")
    )

    title.pack(
        pady=(25, 15)
    )


    # PASSWORD AREA

    password_frame = ctk.CTkFrame(
        password_window,
        fg_color="transparent"
    )

    password_frame.pack(
        padx=30,
        fill="x"
    )


    password_entry = ctk.CTkEntry(
        password_frame,
        placeholder_text="Enter admin password",
        show="●",
        height=42,
        font=("Arial", 15)
    )

    password_entry.pack(
        side="left",
        fill="x",
        expand=True
    )


    password_visible = {
        "value": False
    }


    def toggle_password():

        password_visible["value"] = (
            not password_visible["value"]
        )

        if password_visible["value"]:

            password_entry.configure(
                show=""
            )

            eye_button.configure(
                text="🙈"
            )

        else:

            password_entry.configure(
                show="●"
            )

            eye_button.configure(
                text="👁"
            )


    eye_button = ctk.CTkButton(
        password_frame,
        text="👁",
        width=45,
        height=42,
        command=toggle_password
    )

    eye_button.pack(
        side="right",
        padx=(8, 0)
    )


    # ERROR MESSAGE

    error_label = ctk.CTkLabel(
        password_window,
        text="",
        text_color="#EF4444",
        font=("Arial", 14, "bold")
    )

    error_label.pack(
        pady=(8, 0)
    )


    def verify_password(event=None):

        password = password_entry.get()

        login_button.configure(state="disabled")
        def verified(ok, value):
            if not password_window.winfo_exists():
                return
            login_button.configure(state="normal")
            if ok:
                result["authorized"] = password
                password_window.destroy()
            else:
                error_label.configure(text=str(value), wraplength=340)
                password_entry.focus()
        client.submit('POST', '/admin/verify', {}, password, verified)


    button_frame = ctk.CTkFrame(
        password_window,
        fg_color="transparent"
    )

    button_frame.pack(
        pady=15
    )


    login_button = ctk.CTkButton(
        button_frame,
        text="Confirm",
        width=130,
        command=verify_password
    )

    login_button.pack(
        side="left",
        padx=5
    )


    cancel_button = ctk.CTkButton(
        button_frame,
        text="Cancel",
        width=130,
        fg_color=gray,
        hover_color=gray_hover,
        command=password_window.destroy
    )

    cancel_button.pack(
        side="left",
        padx=5
    )


    password_entry.bind(
        "<Return>",
        verify_password
    )

    password_entry.focus()

    app.wait_window(
        password_window
    )

    return result["authorized"]


# =========================================================
# EMPLOYEE MANAGEMENT
# =========================================================

def add_employee():
    password = check_admin_password()
    if password is None:
        return
    dialog = ctk.CTkInputDialog(text="Employee name:", title="Add Employee")
    name = dialog.get_input()
    if name and name.strip():
        client.submit('POST', '/employees', {'name': name.strip()}, password, mutation_done)


def delete_employee():
    name = selected_employee
    target_ids = employee_ids.get(name, [])
    if not name:
        return
    password = check_admin_password()
    if password is not None:
        client.submit('DELETE', '/employees', {'name': name, 'employee_ids': target_ids}, password, mutation_done)


def select_employee(name):

    global selected_employee

    selected_employee = name

    open_employee_page(
        name
    )


# =========================================================
# CLOCK SYSTEM
# =========================================================

def send_time(employee, action):
    client.submit('POST', '/time-events', {
        'employee': employee, 'action': action, 'employee_ids': employee_ids.get(employee, []),
        'date': datetime.now().strftime('%Y-%m-%d')
    }, callback=mutation_done)


def clock_in(employee):
    send_time(employee, 'clock_in')


def lunch_break(employee):
    today = employee_times.get(employee, {}).get(datetime.now().strftime('%Y-%m-%d'), {})
    send_time(employee, 'break_out' if 'break_in' in today else 'break_in')


def clock_out(employee):
    send_time(employee, 'clock_out')


def show_day_details(employee, date_key):
    day_data = employee_times.get(employee, {}).get(date_key, {})

    details_window = ctk.CTkToplevel(app)
    details_window.title("Shift Details")
    details_window.geometry("430x390")
    details_window.resizable(False, False)
    details_window.transient(app)
    details_window.grab_set()

    formatted_date = datetime.strptime(
        date_key,
        "%Y-%m-%d"
    ).strftime("%B %d, %Y")

    title = ctk.CTkLabel(
        details_window,
        text=employee,
        font=("Arial", 24, "bold")
    )
    title.pack(pady=(25, 5))

    date_label = ctk.CTkLabel(
        details_window,
        text=formatted_date,
        font=("Arial", 16),
        text_color="#9CA3AF"
    )
    date_label.pack(pady=(0, 20))

    clock_in_time = day_data.get("clock_in", "--:--")
    break_in_time = day_data.get("break_in", "--:--")
    break_out_time = day_data.get("break_out", "--:--")
    clock_out_time = day_data.get("clock_out", "--:--")

    details = ctk.CTkFrame(
        details_window,
        fg_color="#111827",
        corner_radius=10
    )
    details.pack(fill="x", padx=30, pady=10)

    times = [
        ("🟢 Clock In", clock_in_time),
        ("🍴 Lunch Break In", break_in_time),
        ("🍴 Lunch Break Out", break_out_time),
        ("🔴 Clock Out", clock_out_time)
    ]

    detail_labels = []
    for label_text, time_text in times:
        row = ctk.CTkFrame(details, fg_color="transparent")
        row.pack(fill="x", padx=15, pady=8)

        label = ctk.CTkLabel(
            row,
            text=label_text,
            font=("Arial", 14, "bold")
        )
        label.pack(side="left")

        time_label = ctk.CTkLabel(
            row,
            text=time_text,
            font=("Arial", 14)
        )
        time_label.pack(side="right")
        detail_labels.append(time_label)

    def refresh_details():
        if not details_window.winfo_exists():
            return
        data = employee_times.get(employee, {}).get(date_key, {})
        for widget, key in zip(detail_labels, ('clock_in', 'break_in', 'break_out', 'clock_out')):
            widget.configure(text=data.get(key, '--:--'))
        title.configure(text=employee if employee in employees else employee + ' (deleted)')
        details_window.after(500, refresh_details)
    refresh_details()

    close_button = ctk.CTkButton(
        details_window,
        text="Close",
        width=130,
        command=details_window.destroy
    )
    close_button.pack(pady=15)


# =========================================================
# EMPLOYEE CLOCK PAGE
# =========================================================

def open_employee_page(employee, year=None, month=None):
    global current_page
    current_page = ('employee', employee, year, month)
    clear_page()

    now = datetime.now()

    if year is None:
        year = now.year

    if month is None:
        month = now.month

    # -----------------------------------------------------
    # TOP
    # -----------------------------------------------------
    top_bar = ctk.CTkFrame(main_area, fg_color="transparent")
    top_bar.pack(fill="x", padx=30, pady=(20, 10))

    back_button = ctk.CTkButton(
        top_bar,
        text="← Back",
        width=90,
        fg_color=gray,
        hover_color=gray_hover,
        command=open_employees
    )
    back_button.pack(side="left")

    employee_name = ctk.CTkLabel(
        top_bar,
        text="👤  " + employee,
        font=("Arial", 28, "bold")
    )
    employee_name.pack(side="left", padx=20)

    # -----------------------------------------------------
    # TODAY'S DATA
    # -----------------------------------------------------
    today_key = now.strftime("%Y-%m-%d")
    today_data = employee_times.get(employee, {}).get(today_key, {})

    clock_in_time = today_data.get("clock_in", "--:--")
    break_in_time = today_data.get("break_in", "--:--")
    break_out_time = today_data.get("break_out", "--:--")
    clock_out_time = today_data.get("clock_out", "--:--")

    # -----------------------------------------------------
    # CLOCK BUTTONS
    # -----------------------------------------------------
    clock_frame = ctk.CTkFrame(main_area, fg_color="transparent")
    clock_frame.pack(pady=(5, 15))

    clock_in_button = ctk.CTkButton(
        clock_frame,
        text="🟢 Clock In",
        width=165,
        height=48,
        font=("Arial", 16, "bold"),
        fg_color=green,
        hover_color=green_hover,
        command=lambda: clock_in(employee)
    )
    clock_in_button.pack(side="left", padx=6)

    lunch_button = ctk.CTkButton(
        clock_frame,
        text="🍴 Lunch Break",
        width=165,
        height=48,
        font=("Arial", 16, "bold"),
        fg_color="#D97706",
        hover_color="#B45309",
        command=lambda: lunch_break(employee)
    )
    lunch_button.pack(side="left", padx=6)

    clock_out_button = ctk.CTkButton(
        clock_frame,
        text="🔴 Clock Out",
        width=165,
        height=48,
        font=("Arial", 16, "bold"),
        fg_color=red,
        hover_color=red_hover,
        command=lambda: clock_out(employee)
    )
    clock_out_button.pack(side="left", padx=6)

    # Button states.
    if clock_in_time != "--:--":
        clock_in_button.configure(state="disabled", text="✓ Clocked In")
    else:
        lunch_button.configure(state="disabled")
        clock_out_button.configure(state="disabled")

    if break_in_time != "--:--" and break_out_time == "--:--":
        lunch_button.configure(text="🍴 End Lunch Break")
        clock_out_button.configure(state="disabled")
    elif break_in_time != "--:--" and break_out_time != "--:--":
        lunch_button.configure(state="disabled", text="✓ Lunch Completed")

    if clock_out_time != "--:--":
        clock_out_button.configure(state="disabled", text="✓ Clocked Out")
        lunch_button.configure(state="disabled")

    # -----------------------------------------------------
    # TODAY STATUS
    # -----------------------------------------------------
    status_frame = ctk.CTkFrame(
        main_area,
        fg_color="#111827",
        corner_radius=10
    )
    status_frame.pack(padx=30, pady=(0, 15), fill="x")

    today_title = ctk.CTkLabel(
        status_frame,
        text="Today",
        font=("Arial", 16, "bold")
    )
    today_title.pack(side="left", padx=20, pady=12)

    times_label = ctk.CTkLabel(
        status_frame,
        text=(
            f"In: {clock_in_time}     "
            f"Lunch: {break_in_time} → {break_out_time}     "
            f"Out: {clock_out_time}"
        ),
        font=("Arial", 14)
    )
    times_label.pack(side="right", padx=20)

    # -----------------------------------------------------
    # CALENDAR
    # -----------------------------------------------------
    calendar_panel = ctk.CTkFrame(
        main_area,
        fg_color="#111827",
        corner_radius=12
    )
    calendar_panel.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=(0, 25)
    )

    # -----------------------------------------------------
    # MONTH NAVIGATION
    # -----------------------------------------------------
    calendar_header = ctk.CTkFrame(calendar_panel, fg_color="transparent")
    calendar_header.pack(pady=(15, 8))

    def previous_month():
        new_month = month - 1
        new_year = year

        if new_month == 0:
            new_month = 12
            new_year -= 1

        open_employee_page(employee, new_year, new_month)

    def next_month():
        new_month = month + 1
        new_year = year

        if new_month == 13:
            new_month = 1
            new_year += 1

        open_employee_page(employee, new_year, new_month)

    previous_button = ctk.CTkButton(
        calendar_header,
        text="◀",
        width=38,
        height=32,
        fg_color=gray,
        hover_color=gray_hover,
        command=previous_month
    )
    previous_button.pack(side="left", padx=10)

    month_name = calendar.month_name[month]

    month_label = ctk.CTkLabel(
        calendar_header,
        text=f"{month_name}  {year}",
        font=("Arial", 20, "bold"),
        width=170
    )
    month_label.pack(side="left")

    next_button = ctk.CTkButton(
        calendar_header,
        text="▶",
        width=38,
        height=32,
        fg_color=gray,
        hover_color=gray_hover,
        command=next_month
    )
    next_button.pack(side="left", padx=10)

    # -----------------------------------------------------
    # CALENDAR GRID
    # -----------------------------------------------------
    calendar_grid = ctk.CTkFrame(calendar_panel, fg_color="transparent")
    calendar_grid.pack(padx=20, pady=5)

    weekday_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

    for column, weekday in enumerate(weekday_names):
        label = ctk.CTkLabel(
            calendar_grid,
            text=weekday,
            width=65,
            font=("Arial", 12, "bold"),
            text_color="#9CA3AF"
        )
        label.grid(row=0, column=column, padx=3, pady=(0, 6))

    month_calendar = calendar.monthcalendar(year, month)

    for row_index, week in enumerate(month_calendar, start=1):
        for column_index, day in enumerate(week):
            if day == 0:
                empty = ctk.CTkLabel(
                    calendar_grid,
                    text="",
                    width=55,
                    height=38
                )
                empty.grid(
                    row=row_index,
                    column=column_index,
                    padx=4,
                    pady=4
                )
                continue

            date_key = f"{year}-{month:02d}-{day:02d}"
            day_data = employee_times.get(employee, {}).get(date_key, {})

            has_in = "clock_in" in day_data
            has_out = "clock_out" in day_data

            if has_in and has_out:
                day_color = green
            elif has_in:
                day_color = yellow
            else:
                day_color = gray

            day_box = ctk.CTkButton(
                calendar_grid,
                text=str(day),
                width=55,
                height=38,
                fg_color=day_color,
                hover_color=blue_hover,
                corner_radius=6,
                font=("Arial", 13, "bold"),
                command=lambda selected_date=date_key: show_day_details(
                    employee,
                    selected_date
                )
            )
            day_box.grid(
                row=row_index,
                column=column_index,
                padx=4,
                pady=4
            )

    # -----------------------------------------------------
    # LEGEND
    # -----------------------------------------------------
    legend = ctk.CTkLabel(
        calendar_panel,
        text=(
            "🟢 Completed shift      "
            "🟡 Shift in progress      "
            "⬛ No record      "
            "Click a date to see times"
        ),
        font=("Arial", 12),
        text_color="#9CA3AF"
    )
    legend.pack(pady=(5, 10))


# =========================================================
# EMPLOYEES PAGE
# =========================================================

def open_employees():
    global current_page
    current_page = ('employees',)

    clear_page()


    # -----------------------------------------------------
    # TOP BAR
    # -----------------------------------------------------

    top_bar = ctk.CTkFrame(
        main_area,
        fg_color="transparent"
    )

    top_bar.pack(
        fill="x",
        padx=30,
        pady=25
    )


    title_area = ctk.CTkFrame(
        top_bar,
        fg_color="transparent"
    )

    title_area.pack(side="left")

    title = ctk.CTkLabel(
        title_area,
        text="Employees",
        font=("Segoe UI", 30, "bold"),
        text_color="#F8FAFC"
    )

    title.pack(anchor="w")

    subtitle = ctk.CTkLabel(
        title_area,
        text="Manage your team and employee activity",
        font=("Segoe UI", 13),
        text_color="#94A3B8"
    )

    subtitle.pack(
        anchor="w",
        pady=(2, 0)
    )


    delete_button = ctk.CTkButton(
        top_bar,
        text="Delete Employee",
        width=140,
        height=40,
        fg_color=red,
        hover_color=red_hover,
        command=delete_employee
    )

    delete_button.pack(
        side="right",
        padx=5
    )


    add_button = ctk.CTkButton(
        top_bar,
        text="+ Add Employee",
        width=140,
        height=40,
        fg_color=blue,
        hover_color=blue_hover,
        command=add_employee
    )

    add_button.pack(
        side="right",
        padx=5
    )


    # -----------------------------------------------------
    # EMPLOYEE LIST
    # -----------------------------------------------------

    employee_list = ctk.CTkScrollableFrame(
        main_area,
        fg_color="#111827"
    )

    employee_list.pack(
        fill="both",
        expand=True,
        padx=30,
        pady=(0, 30)
    )


    if len(employees) == 0:

        empty_text = ctk.CTkLabel(
            employee_list,
            text="No employees added yet.",
            font=("Arial", 16),
            text_color="#9CA3AF"
        )

        empty_text.pack(
            pady=30
        )


    for employee in employees:

        employee_button = ctk.CTkButton(
            employee_list,
            text="👤  " + employee,
            height=50,
            anchor="w",
            font=("Arial", 16),
            fg_color=gray,
            hover_color=blue_hover,
            command=lambda name=employee: select_employee(
                name
            )
        )

        employee_button.pack(
            fill="x",
            padx=10,
            pady=5
        )


# =========================================================
# SIDEBAR BUTTONS
# =========================================================

items_button = ctk.CTkButton(
    sidebar,
    text="📦  Items",
    height=55,
    font=("Arial", 18, "bold"),
    fg_color=blue,
    hover_color=blue_hover,
    corner_radius=10,
    command=open_items
)

items_button.pack(
    padx=20,
    pady=10,
    fill="x"
)


cart_button = ctk.CTkButton(
    sidebar, text='🛒  Cart', height=55, font=('Arial',18,'bold'),
    fg_color=blue, hover_color=blue_hover, corner_radius=10, command=open_cart)
cart_button.pack(padx=20,pady=10,fill='x')


tracking_button = ctk.CTkButton(
    sidebar,
    text="📊  Daily Tracking",
    height=55,
    font=("Arial", 18, "bold"),
    fg_color=blue,
    hover_color=blue_hover,
    corner_radius=10,
    command=open_tracking
)

tracking_button.pack(
    padx=20,
    pady=10,
    fill="x"
)


employees_button = ctk.CTkButton(
    sidebar,
    text="👥  Employees",
    height=55,
    font=("Arial", 18, "bold"),
    fg_color=blue,
    hover_color=blue_hover,
    corner_radius=10,
    command=open_employees
)

employees_button.pack(
    padx=20,
    pady=10,
    fill="x"
)


# =========================================================
# START
# =========================================================

def show_sync_conflicts():
    window = ctk.CTkToplevel(app)
    window.title('SaveSales synchronization review')
    window.geometry('650x430')
    window.transient(app)
    text = ctk.CTkTextbox(window, wrap='word')
    text.pack(fill='both', expand=True, padx=15, pady=15)
    text.insert('end', 'Conflicting records remain in the local SQLite journal. The calendar uses the same deterministic result on every PC.\n\n')
    for event in sync_conflicts:
        text.insert('end', f"{event['name']} | {event['date']} | {event['action']}\n"
                    f"Recorded: {event['time']} | Calendar: {event.get('selected_time') or '--'}\n"
                    f"{event['reason']}\nRecord ID: {event['id']}\n\n")
    text.configure(state='disabled')


conflict_button = ctk.CTkButton(sidebar, text='Review time conflicts',
                               fg_color=yellow, command=show_sync_conflicts)
connection_label = ctk.CTkLabel(
    sidebar, text='● No SaveSales LAN connection', text_color=red,
    font=('Segoe UI', 12), wraplength=190)
connection_label.pack(side='bottom', padx=10, pady=20)


def close_app():
    if getattr(app, '_closing', False):
        return
    app._closing = True
    client.close()
    app.withdraw()
    def finish_close():
        if client.thread.is_alive():
            app.after(100, finish_close)
        else:
            app.destroy()
    finish_close()


shop = ShopUI(app, main_area, client, check_admin_password, set_shop_page, lambda: current_page[0])
app.protocol('WM_DELETE_WINDOW', close_app)
open_items()
process_network()
app.mainloop()